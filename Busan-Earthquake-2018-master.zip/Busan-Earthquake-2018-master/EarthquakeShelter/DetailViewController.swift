//
//  DetailViewController.swift
//  EarthquakeShelter
//
//  Created by D7703_18 on 2018. 11. 12..
//  Copyright © 2018년 201550057. All rights reserved.
//

import UIKit
import MapKit

class DetailViewController: UITableViewController, MKMapViewDelegate {
    @IBOutlet weak var lblAddr: UILabel!
    @IBOutlet weak var lbldetailAddr: UILabel!
    @IBOutlet weak var lblCapcity: UILabel!
    @IBOutlet var detailmap: MKMapView!
    
    var selectedForDetail: BusanData?
    var test: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let title = selectedForDetail?.title
        let subtitle = selectedForDetail?.subtitle
        let capcity = selectedForDetail?.capcity
        let coordinate = selectedForDetail?.coordinate
        
        lblAddr.text = title
        lbldetailAddr.text = subtitle
        lblCapcity.text = capcity
        detailmap.setCenter(coordinate!, animated: true)
    }
    func configure(location: String) {
        
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(location, completionHandler: {
            
            (placemarks: [CLPlacemark]?, error: Error?) -> Void in
            
            if let error = error {
                print(error)
                return
            }
            
            if placemarks != nil {
                let placemark = placemarks![0]
                
                // Add annotation
                let annotation = MKPointAnnotation()
                //annotation.title = self.name
                //annotation.subtitle = self.type
                
                if let location = placemark.location {
                    annotation.coordinate = location.coordinate
                    self.detailmap.addAnnotation(annotation)
                    
                    // Set zoom level
                    let region = MKCoordinateRegionMakeWithDistance(annotation.coordinate, 250, 250)
                    self.detailmap.setRegion(region, animated: true)
                }
            }
            
        })
}

}
